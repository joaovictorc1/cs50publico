#include <cs50.h>
#include <stdio.h>

int main(void)
{
    char *s = "HI!";
    string s1 = "HI1!";
    printf("%s\n", s);
    printf("%s\n", s1);

    printf("%c", *s);
    printf("%c", *(s + 1));
    printf("%c\n", *(s + 2));
}
