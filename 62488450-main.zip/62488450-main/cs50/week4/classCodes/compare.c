#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    char *s = get_string("s: ");
    char *t = get_string("t: ");

    // if (s == t) // Não é assim, porque assim você estaria comparando o endereço de memória do primeiro char de cada uma e não a string per se
    if (strcmp(s, t) == 0) // Essa é a maneira correta porque compara cada char individualmente
    {
        printf("Same\n");
    }
    else
    {
        printf("Different\n");
    }
    return 0;
}
